package com.luki.lukiiteminspector.client;

public final class InspectState {
    public static final InspectState INSTANCE = new InspectState();

    public boolean inspecting;
    /** 0..1, avancado a cada tick. */
    public float progress, prevProgress;
    /** Rotacao alvo (graus) controlada pelo mouse. */
    public float rotX, rotY;
    /** Rotacao suavizada, usada no render. */
    public float smoothRotX, smoothRotY, prevSmoothRotX, prevSmoothRotY;
    public float zoom = 1.0F;

    private InspectState() {}

    public void resetPose() {
        rotX = 0; rotY = 0; zoom = 1.0F;
    }

    public void stop() {
        inspecting = false;
    }

    public boolean visible() {
        return inspecting || progress > 0.001F || prevProgress > 0.001F;
    }
}
