package com.luki.lukiiteminspector.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import org.lwjgl.glfw.GLFW;

public final class LukiItemInspectorClient {
    public static InspectConfig CONFIG = new InspectConfig();
    public static KeyMapping inspectKey;
    public static KeyMapping resetKey;

    private LukiItemInspectorClient() {}

    public static void initialize(IEventBus modEventBus) {
        CONFIG = InspectConfig.load();
        inspectKey = new KeyMapping("key.lukiiteminspector.inspect", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_I, "category.lukiiteminspector");
        resetKey = new KeyMapping("key.lukiiteminspector.reset", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_O, "category.lukiiteminspector");
        modEventBus.addListener((RegisterKeyMappingsEvent event) -> {
            event.register(inspectKey);
            event.register(resetKey);
        });
        MinecraftForge.EVENT_BUS.addListener(LukiItemInspectorClient::onClientTick);
    }

    private static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft minecraft = Minecraft.getInstance();
        InspectState state = InspectState.INSTANCE;
        LocalPlayer player = minecraft.player;

        state.prevProgress = state.progress;
        state.prevSmoothRotX = state.smoothRotX;
        state.prevSmoothRotY = state.smoothRotY;

        if (player == null || minecraft.screen != null
                || (player.getMainHandItem().isEmpty() && player.getOffhandItem().isEmpty())) {
            state.stop();
            while (inspectKey.consumeClick()) { /* descarta */ }
        } else {
            while (inspectKey.consumeClick()) state.inspecting = !state.inspecting;
        }
        while (resetKey.consumeClick()) state.resetPose();

        float speed = 0.12F * CONFIG.animationSpeed * 2.0F;
        state.progress = state.inspecting
                ? Math.min(1.0F, state.progress + speed)
                : Math.max(0.0F, state.progress - speed);

        float smooth = Math.min(1.0F, 0.25F * CONFIG.animationSpeed);
        state.smoothRotX += (state.rotX - state.smoothRotX) * smooth;
        state.smoothRotY += (state.rotY - state.smoothRotY) * smooth;
        if (!state.visible()) {
            // fora da inspecao a pose volta ao inicio para a proxima vez
            state.rotX = state.rotY = state.smoothRotX = state.smoothRotY = 0;
            state.prevSmoothRotX = state.prevSmoothRotY = 0;
            state.zoom = 1.0F;
        }
    }
}
