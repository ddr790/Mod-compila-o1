package com.luki.lukiiteminspector.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.logging.LogUtils;
import net.minecraftforge.fml.loading.FMLPaths;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class InspectConfig {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FMLPaths.CONFIGDIR.get().resolve("lukiiteminspector.json");

    public float rotationSensitivity = 1.0F;
    /** Distancia do item a camera (unidades de bloco). */
    public float itemDistance = 1.0F;
    /** Escala base do item. */
    public float itemScale = 0.8F;
    /** Altura do centro do item em relacao ao centro da tela (positivo = acima). */
    public float itemHeight = 0.12F;
    public float animationSpeed = 1.0F;
    public boolean showHands = true;
    public float minZoom = 0.5F;
    public float maxZoom = 2.5F;

    public static InspectConfig load() {
        InspectConfig config = new InspectConfig();
        if (Files.exists(FILE)) {
            try {
                InspectConfig read = GSON.fromJson(Files.readString(FILE), InspectConfig.class);
                if (read != null) config = read;
            } catch (Exception exception) {
                LOGGER.error("Could not read {}, using default item inspector settings", FILE, exception);
            }
        }
        config.sanitize();
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(config));
        } catch (IOException exception) {
            LOGGER.error("Could not write item inspector settings to {}", FILE, exception);
        }
        return config;
    }

    private void sanitize() {
        rotationSensitivity = validRange(rotationSensitivity, 0.1F, 5.0F, 1.0F);
        itemDistance = validRange(itemDistance, 0.5F, 3.0F, 1.0F);
        itemScale = validRange(itemScale, 0.1F, 3.0F, 0.8F);
        itemHeight = validRange(itemHeight, -0.5F, 0.5F, 0.12F);
        animationSpeed = validRange(animationSpeed, 0.1F, 4.0F, 1.0F);
        minZoom = validRange(minZoom, 0.1F, 1.0F, 0.5F);
        maxZoom = validRange(maxZoom, 1.0F, 5.0F, 2.5F);
    }

    private static float validRange(float value, float minimum, float maximum, float fallback) {
        if (!Float.isFinite(value)) return fallback;
        return Math.max(minimum, Math.min(maximum, value));
    }
}
