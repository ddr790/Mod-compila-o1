package com.luki.lukiiteminspector.mixin;

import com.luki.lukiiteminspector.client.InspectState;
import com.luki.lukiiteminspector.client.LukiItemInspectorClient;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MouseHandler.class)
public abstract class MouseMixin {
    @Shadow private double accumulatedDX;
    @Shadow private double accumulatedDY;

    /** Enquanto inspeciona, o mouse gira o item e nao a camera do jogador. */
    @Inject(method = "turnPlayer", at = @At("HEAD"), cancellable = true)
    private void luki$captureRotation(CallbackInfo ci) {
        InspectState state = InspectState.INSTANCE;
        if (!state.inspecting) return;
        float sensitivity = 0.3F * LukiItemInspectorClient.CONFIG.rotationSensitivity;
        state.rotY += (float) (this.accumulatedDX * sensitivity);
        state.rotX = Math.max(-135.0F, Math.min(135.0F, state.rotX + (float) (this.accumulatedDY * sensitivity)));
        this.accumulatedDX = 0.0D;
        this.accumulatedDY = 0.0D;
        ci.cancel();
    }

    @Inject(method = "onScroll(JDD)V", at = @At("HEAD"), cancellable = true)
    private void luki$captureScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        InspectState state = InspectState.INSTANCE;
        if (!state.inspecting || vertical == 0.0D) return;
        var config = LukiItemInspectorClient.CONFIG;
        state.zoom = Math.max(config.minZoom, Math.min(config.maxZoom, state.zoom + (float) vertical * 0.1F));
        ci.cancel();
    }
}
