package com.luki.lukiiteminspector;

import com.luki.lukiiteminspector.client.LukiItemInspectorClient;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(LukiItemInspector.MOD_ID)
public class LukiItemInspector {
    public static final String MOD_ID = "lukiiteminspector";

    public LukiItemInspector() {
        DistExecutor.safeRunWhenOn(Dist.CLIENT, () -> () ->
                LukiItemInspectorClient.initialize(FMLJavaModLoadingContext.get().getModEventBus()));
    }
}
