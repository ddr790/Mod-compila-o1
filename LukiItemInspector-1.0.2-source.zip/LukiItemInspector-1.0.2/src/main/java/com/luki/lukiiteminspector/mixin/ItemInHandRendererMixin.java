package com.luki.lukiiteminspector.mixin;

import com.luki.lukiiteminspector.client.InspectState;
import com.luki.lukiiteminspector.client.LukiItemInspectorClient;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Durante a inspecao o renderizador de maos do vanilla e substituido por uma pose
 * de duas maos (a mesma usada para segurar mapas): os dois bracos formam o "V" na
 * parte inferior da tela, com a skin do jogador, e o item 3D fica no centro, diante
 * da camera, girando em torno do proprio centro.
 *
 * A versao 1.0.1 apenas empurrava/rotacionava a PoseStack em volta da origem da camera
 * e deixava o vanilla desenhar o item na posicao da mao direita (canto inferior direito),
 * por isso o item girava "em orbita" no canto e so uma mao aparecia.
 */
@Mixin(ItemInHandRenderer.class)
public abstract class ItemInHandRendererMixin {

    @Shadow protected abstract void renderMapHand(PoseStack poseStack, MultiBufferSource buffer, int light, HumanoidArm arm);
    @Shadow protected abstract float calculateMapTilt(float pitch);

    @Inject(method = "renderHandsWithItems", at = @At("HEAD"), cancellable = true)
    private void luki$renderInspection(float partialTick, PoseStack poseStack,
                                       MultiBufferSource.BufferSource buffers,
                                       LocalPlayer player, int light, CallbackInfo ci) {
        InspectState state = InspectState.INSTANCE;
        if (!state.visible()) return;
        ItemStack stack = player.getMainHandItem().isEmpty() ? player.getOffhandItem() : player.getMainHandItem();
        if (stack.isEmpty()) return; // deixa o vanilla desenhar normalmente

        var config = LukiItemInspectorClient.CONFIG;
        float progress = Mth.lerp(partialTick, state.prevProgress, state.progress);
        float eased = progress * progress * (3.0F - 2.0F * progress);
        float rotX = Mth.lerp(partialTick, state.prevSmoothRotX, state.smoothRotX);
        float rotY = Mth.lerp(partialTick, state.prevSmoothRotY, state.smoothRotY);

        ClientLevel level = Minecraft.getInstance().level;
        float time = (level == null ? 0L : level.getGameTime()) + partialTick;
        float swayX = Mth.sin(time * 0.05F) * 0.006F;
        float swayY = Mth.cos(time * 0.04F) * 0.006F;

        // ---- Bracos: pose vanilla de duas maos ----
        if (config.showHands && !player.isInvisible()) {
            poseStack.pushPose();
            float tilt = this.calculateMapTilt(player.getXRot());
            poseStack.translate(0.0F, 0.04F + (1.0F - eased) * -1.2F + tilt * -0.5F, -0.72F);
            poseStack.mulPose(Axis.XP.rotationDegrees(tilt * -85.0F));
            poseStack.pushPose();
            poseStack.mulPose(Axis.YP.rotationDegrees(90.0F));
            this.renderMapHand(poseStack, buffers, light, HumanoidArm.RIGHT);
            this.renderMapHand(poseStack, buffers, light, HumanoidArm.LEFT);
            poseStack.popPose();
            poseStack.popPose();
        }

        // ---- Item: centro da tela, em espaco de camera ----
        poseStack.pushPose();
        float zoom = Mth.clamp(state.zoom, config.minZoom, config.maxZoom);
        poseStack.translate(swayX, config.itemHeight + swayY - (1.0F - eased) * 0.9F, -config.itemDistance);
        poseStack.scale(config.itemScale * zoom * eased, config.itemScale * zoom * eased, config.itemScale * zoom * eased);
        poseStack.mulPose(Axis.XP.rotationDegrees(rotX));
        poseStack.mulPose(Axis.YP.rotationDegrees(rotY));
        // O contexto FIXED ja inclui meia-volta em Y (feito para item frames); compensa
        // para a frente do item ficar virada para o jogador.
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F));
        Minecraft.getInstance().getItemRenderer().renderStatic(player, stack, ItemDisplayContext.FIXED, false,
                poseStack, buffers, level, light, OverlayTexture.NO_OVERLAY, player.getId());
        poseStack.popPose();

        buffers.endBatch();
        ci.cancel();
    }
}
