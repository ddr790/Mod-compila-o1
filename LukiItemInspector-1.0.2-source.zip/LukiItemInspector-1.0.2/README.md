# Luki Item Inspector 1.0.2 (Forge 1.20.1)
Codigo-fonte reconstruido a partir do JAR 1.0.1 (nao havia fontes). **NAO compilado nem testado em jogo** no ambiente onde foi escrito.

Compilar (Java 17, com internet): `gradle wrapper --gradle-version 8.1.1` (uma vez) e depois `./gradlew build`.
JAR final: build/libs/LukiItemInspector-1.0.2-forge-1.20.1.jar
Teclas padrao (reconstruidas, reatribuiveis em Controles): I = inspecionar, O = resetar pose. Mouse gira, scroll da zoom.
